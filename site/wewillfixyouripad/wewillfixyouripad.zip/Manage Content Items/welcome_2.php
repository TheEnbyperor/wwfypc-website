<?php 

include_once("../admin/require/webconfig.inc_2.php");

?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>

    <td width="650" colspan="2" style="padding-top:15px;"><p class="bodytext"><strong>Welcome to Administration Area for</strong><br>

        <span class="bluetitle"><?php echo WEBSITE_NAME;?></span><br>

        <br>

        Thank you for choosing SabriTech's Content Management System. We sincerely hope that this Content Management System will enable you to successfully manage your website. <br />

        <br />

        In case you have any queries or concerns, please contact us on 0207 993 5333. Your feedback is extremely valuable for us.

      <p>

      <p class="bodytext"><font color="#0000FF">The Sabri Tech Team</font><br>

        <br />

        <br />

        <br />

        <br />

        <br />

        <br />

      </p></td>

  </tr>

</table>

