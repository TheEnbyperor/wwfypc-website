CKEDITOR.editorConfig = function( config ) {
};