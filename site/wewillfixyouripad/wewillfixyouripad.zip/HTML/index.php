<?php 
    	     $index = "S"; 
			include_once("includes/header.php");
			
         ?>
         <div id="featured"> 
			
			<img src="images/Slide1.jpg" />
			<img src="images/Slide2.jpg" />
			<img src="images/Slide3.jpg" />
			<img src="images/Slide4.jpg" />
		</div>
            	
                
                
            </div>
            <div class="rightpanel">
            	<?php 
    	    
			include_once("includes/contact.php");
			
         ?>
                
            </div>
        </div>
        <div class="supportdiv">
        	<div class="maindiv">
            	<div class="support">
                	<a href="services.php"><img src="images/support.jpg" alt=""/></a>
                	<div class="supporth">
                    	<span style="color:#fff;">Phone</span> Support

                    </div>
                    <div class="supportp">
                    	Fantastic help and advice given over the phone for anything from a small problem to buying a new computer.</div>
              </div>
                <div class="support1">
                	<a href="services.php"><img src="images/support1.jpg" alt=""/></a>
                	<div class="supporth">
                    	<span style="color:#fff;">Simple</span> Issues

                    </div>
                    <div class="supportp">
                    	Routine maintenance such as software installs, data transfer, memory upgrades, password removal etc.</div>
              </div>
                <div class="support2">
                	<a href="services.php"><img src="images/support2.jpg" alt=""/></a>
                	<div class="supporth">
                    	<span style="color:#fff;">Complex</span> Issues

                    </div>
                    <div class="supportp">
                    	Hardware and software repairs such as laptop power socket repair, virus removal, system rebuilds etc.</div>
              </div>
                <div class="support3">
                	<a href="services.php"><img src="images/support3.jpg" alt=""/></a>
                	<div class="supporth">
                    	<span style="color:#fff;">Critical </span> Issues

                    </div>
                    <div class="supportp">
                    	Hardware issues that require parts such as laptop screen replacements, laptop motherboard repairs etc.</div>
              </div>
                
                
            </div>
        </div>
        <div class="maindiv">
        	<div class="leftpanel">
        	<div class="whead" style="text-transform:uppercase; ">
            	Welcome to We WILL Fix Your PC
            </div>
            <div class="wpara" style="margin-bottom:0px;">
            	Hello and a warm welcome to We WILL Fix Your PC .co.uk. Perhaps you are here because something has gone wrong with your desktop or laptop. Maybe it’s just suddenly stopped working, or perhaps you'd just like to get more out of your system? Whatever the problem, I'm your guy for computer repairs! With my personal service, your computer will work faster and be more efficient. With my advice and support, hopefully we can avoid any more problems in the future. With my no fix no fee guarantee you have nothing to lose. Sound good? Read on...<br/><br/>

We WILL Fix Your PC are based in Cardiff and we offer a highly competitive hourly rate coupled with a truly personal service to give you excellent value for money and less of a headache! Our skills include computer repair, laptop repair, laptop screen replacement, virus removal, new computer installation, Windows 7, XP, vista, wireless setup, spyware detection, file recovery, printer problems and so much more. We always explain exactly what needs doing and why and we promise to do it in plain and simple English.<br/><br/>

With over 15 years’ experience working in the IT industry this gives us the confidence to say whatever your problem, whether it be large or small we can accommodate you in the best way possible to meet your needs. We guarantee you will be satisfied with the service you receive from us or your money back.<br/><br/>

Why not give us a try - we really believe in "going the extra mile". 
            </div>
        </div>
            <div class="rightpanel">
            	<a href="appointment.php"><img src="images/contact.bmp" alt=""/></a>
            </div>
        </div>
        <div class="quote">
        	<div class="maindiv">
            	<div class="quoteimg">
                	<img src="images/lady.jpg" alt=""/>
                </div>
                <div class="quotetext">
                	<span><img src="images/quote.jpg" alt=""/></span> I received a fantastic service. Everything was explained very well and I am extremely pleased with the &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;service I received. I would recommend them any day. Lisa Green, Canton. <span><img src="images/quoteb.jpg" alt=""/></span>
                </div>
            </div>
        </div>
        
<?php 
    	    
			include_once("includes/footer.php");
			
         ?>
