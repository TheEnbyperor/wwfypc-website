<?php 
    	     $choose = "S"; 
			include_once("includes/header.php");
			
         ?>
            	<div class="whead">
                	Why choose We WILL Fix Your PC?
                </div>
                <div class="wpara">
                	There are a lot of computer repair companies in Cardiff. It's hard to tell them apart sometimes. Think about this - What separates a top-notch computer repair shop from the 16 year old on Gum tree? Computer repair shops go out of business all of the time. There's high turnover and there's no guarantee that the person working on your computer knows anything other than how to turn it on. We WILL Fix Your PC has been in this business since 1995.<br/><br/>

Our Goal: To be the best in Cardiff.<br/><br/>

No one in Cardiff works harder for you. No one has the strong referrals, customer loyalty and personal testimonials that we have. We're committed to you, your needs, and accomplishing your goals quickly and affordably. We have strong work ethics, a lot of integrity, respect for our customers, and the patience to listen to what you really want out of a computer repair service.<br/><br/>

The following are several other great reasons you’ll be glad you’ve decided to turn your computer over to us: 
                </div>
                <div class="maindiv">
                	<div class="bullet">
                    	<div class="bulletimg"><img src="images/1.jpg" width="36" height="35" />                        </div>
          <div class="bullettext">
                        	<span style="color:#3990BD; font-size:17px;">We offer a lowest price guarantee</span><br/>
                            <span style="color:#4a4344; font-size:13px;">We are confident that we'll beat any quote. Please give us a call.</span>
                        </div>
                    </div>
                    <div class="bullet">
                    	<div class="bulletimg"><img src="images/2.jpg" width="36" height="35" />                        </div>
                        <div class="bullettext">
                        	<span style="color:#3990BD; font-size:17px;">No Fix - No Fee</span>
                   	    <br/>
                            <span style="color:#4a4344; font-size:13px;">With our satisfaction guarantee if the problem is not fixed its free!</span>                        </div>
                  </div>
                    <div class="bullet">
                    	<div class="bulletimg"><img src="images/3.jpg" width="36" height="35" /></div>
                        <div class="bullettext">
                        	<span style="color:#3990BD; font-size:17px; ">Quick repair turnaround</span>
                   	    <br/>
                            <span style="color:#4a4344; font-size:13px; ">We are fast! Offering a same day service and most jobs completed on site.</span>                        </div>
                  </div>
                    <div class="bullet">
                    	<div class="bulletimg"><img src="images/4.jpg" width="37" height="36" /></div>
                        <div class="bullettext">
                        	<span style="color:#3990BD; font-size:17px;">Quick repair turnaround</span>
                   	    <br/>
                            <span style="color:#4a4344; font-size:13px;">We are fast! Offering a same day service and most jobs completed on site.</span>                        </div>
                  </div>
                    <div class="bullet">
                    	<div class="bulletimg"><img src="images/5.jpg" width="36" height="35" /></div>
                        <div class="bullettext">
                        	<span style="color:#3990BD; font-size:17px;">Specific appointment times</span>
                   	    <br/>
                            <span style="color:#4a4344; font-size:13px;">We have specific appointment times so you’re not waiting around all day.</span>                        </div>
                  </div>
                    <div class="bullet">
                    	<div class="bulletimg"><img src="images/6.jpg" width="39" height="35" /></div>
                        <div class="bullettext">
                        	<span style="color:#3990BD; font-size:17px;">Longer working hours</span>
                   	    <br/>
                            <span style="color:#4a4344; font-size:13px;">We work daytime, evenings and weekends – 7 days a week.</span>                        </div>
                  </div>
                    <div class="bullet">
                    	<div class="bulletimg"><img src="images/7.jpg" width="36" height="35" /></div>
                        <div class="bullettext">
                        	<span style="color:#3990BD; font-size:17px;">90 day guarantee / warranty</span>
                   	    <br/>
                            <span style="color:#4a4344; font-size:13px;">All work and parts are covered by our no quibble 90 day guarantee.</span>                        </div>
                  </div>
                    <div class="bullet">
                    	<div class="bulletimg"><img src="images/8.jpg" width="39" height="35" /></div>
                        <div class="bullettext">
                        	<span style="color:#3990BD; font-size:17px;">Local personalised service</span>
                   	    <br/>
                            <span style="color:#4a4344; font-size:13px;">We are your local computer repair company in Cardiff with the personal touch.</span>                        </div>
                  </div>
                    
                </div>
            </div>
            <div class="rightpanel">
            	<?php 
    	    
			include_once("includes/contact.php");
			
         ?>
         		 <a href="appointment.php"><img src="images/NoJargon.bmp" alt="" class="right" style="margin-top:25px;"/></a>
                <a href="appointment.php"><img src="images/FixedPrice.bmp" alt="" class="right" style="margin-top:25px;"/></a>
                <a href="appointment.php"><img src="images/9.bmp" alt="" class="right" style="margin-top:25px;"/></a>
                <a href="appointment.php"><img src="images/nofix.bmp" alt="" class="right" style="margin-top:25px;"/></a>
               
            </div>
        </div>
        		<div class="quote">
        	<div class="maindiv">
            	<div class="quoteimg">
                	<img src="images/t_3.jpg" alt=""/>
                </div>
                <div class="quotetext">
                	<span><img src="images/quote.jpg" alt=""/></span> After my initial call my computer was picked up and dropped off fixed and working again within 24 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;hours. The service I received was excellent. Sandra Thomas, Lisvane. <span><img src="images/quoteb.jpg" alt=""/></span>
                </div>
            </div>
        </div>
<?php 
    	    
			include_once("includes/footer.php");
			
         ?>
