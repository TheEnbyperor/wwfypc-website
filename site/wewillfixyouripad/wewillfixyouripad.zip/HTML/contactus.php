<?php 
    	     $contactus = "S"; 
			include_once("includes/header.php");
			
         ?>
            	<div class="whead2">
                	Great
                </div>
                <div class="whead2" style="color:#ff7b00;">
                	Tech Support
                </div>
                <div class="whead2" style="font-size:18px;">
                	is only a phone call away
                </div>
                <div class="maindiv">
                	<div class="cleft">
                    	 <div class="whead2" style="font-size:22px; color:#3990bd; margin-top:29px;">
                	By Phone :
                </div>
                         <div class="whead" style="color:#8b0000; margin-top:11px;">
                                02920 758299
                            </div>
                         <div class="whead" style="color:#8b0000; margin-top:11px;">
                                07999 056096
                            </div>
                         <div class="whead2" style="font-size:22px; color:#3990bd; margin-top:42px;">
                	By Email :<br/>
                    <a href="mailto:neil@willfixyourpc.co.uk">neil@willfixyourpc.co.uk</a>
                </div>
                    </div>
                    <div class="cleft">
                    	 <div class="whead2" style="font-size:22px; color:#3990bd; margin-top:29px;">
                	By Post or Visit :
                </div>
                         <div class="whead" style="color:#494949; margin-top:11px; font-size:22px;">
                                2 Tatham Road<br/>
Llanishen<br/>
Cardiff<br/>
CF14 5FB<br/>
                            </div>
                         
                         <div class="whead2" style="font-size:22px; color:#3990bd; margin-top:44px;">
                	Location Map :
                </div>
                    </div>
                </div>
               
                
                
                <div class="maindiv" id="map" style="margin-top:70px;">
                	<img src="images/Map.bmp" alt=""/>
                </div>
                
            </div>
            <div class="rightpanel">
            	<?php 
    	    
			include_once("includes/contact.php");
			
         ?>
                
                <a href="appointment.php"><img src="images/free.bmp" alt="" class="right" style="margin-top:25px;"/></a>
                <a href="appointment.php"><img src="images/buy.bmp" alt="" class="right" style="margin-top:25px;"/></a>
                <a href="appointment.php"><img src="images/repair.bmp" alt="" class="right" style="margin-top:25px;"/></a>
                <a href="appointment.php"><img src="images/urgent.bmp" alt="" class="right" style="margin-top:25px;"/></a>
                
            </div>
        </div>
        <div class="quote">
        	<div class="maindiv">
            	<div class="quoteimg">
                	<img src="images/t_5.jpg" alt=""/>
                </div>
                <div class="quotetext">
                	<span><img src="images/quote.jpg" alt=""/></span> All the problem I had have been sorted out and the advice given to me was all relevant. I would &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;recommend them to anyone who wants a fast and efficient service. Louise Williams, Health. <span><img src="images/quoteb.jpg" alt=""/></span>
                </div>
            </div>
        </div>
<?php 
    	    
			include_once("includes/footer.php");
			
         ?>
