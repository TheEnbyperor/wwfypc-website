        
        <div class="footer">
        	<div class="copy">
            	Copyright &copy; 2011 wewillfixyourpc.co.uk. All Rights Reserved.

            </div>
            <div class="powered">
            	Powered by <a href="http://portfolio.sabritech.com" target="_blank">SabriTech</a>

            </div>
        </div>
    </div>
</body>
</html>
