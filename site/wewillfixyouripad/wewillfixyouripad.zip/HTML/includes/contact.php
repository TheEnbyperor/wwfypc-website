<div class="contactbg">
                	<div class="cemail">
                    	<input type="text" class="cinput" value="Name" onfocus="this.value=''"/>
                    </div>
                    <div class="cemail1">
                    	<input type="text" class="cinput" value="Tel No" onfocus="this.value=''"/>
                    </div>
                    <div class="cemail2">
                    	<input type="text" class="cinput" value="Email" onfocus="this.value=''"/>
                    </div>
                    <div class="message">
                    	<textarea class="cinput1" style="overflow:hidden;" rows="1" cols="1" onfocus="this.value=''">Message</textarea>
                    </div>
                    
                    	<a href="#"><img src="images/submit.jpg" class="submitbtn"/></a>
                   
                </div>