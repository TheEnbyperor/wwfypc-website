<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>We will fix your pc</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/slider.css" rel="stylesheet" type="text/css" />
<link href="css/slider_main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery-1.5.1.min.js"></script>
<script type="text/javascript" src="js/jquery.orbit-1.2.3.min.js"></script>
<script type="text/javascript">
			$(window).load(function() {
				$('#featured').orbit();
			});
		</script>
</head>

<body>
	<div class="container">
    	<div class="header">
        	<a href="index.php"><img src="images/logo.png" alt="" class="logo"/></a>
            <a href="contactus.php"><img src="images/map.jpg" alt="" class="map"/></a>
            <div class="call">
            	Call Now<br/>
               <span style="color:#000;"> 02920 758299</span>
               <span style="color:#494949; font-size:11px; font-weight:bold; text-align:left; float:left;">No Fix. No Fee. Prices start from &pound;19</span>
            </div>
            <div class="menu">
            	<a href="index.php" class="menuh<?=$index?>">Home</a>
                <img src="images/separator.jpg" class="left"/>
                <a href="help.php" class="menua<?=$help?>">Who We Help</a>
                <img src="images/separator.jpg" class="left"/>
                <a href="choose.php" class="menua<?=$choose?>">Why Choose Us ?</a>
                <img src="images/separator.jpg" class="left"/>
                <a href="services.php" class="menua<?=$services?>">Services and Prices</a>
                <img src="images/separator.jpg" class="left"/>
                <a href="contactus.php" class="menuc<?=$contactus?>">Contact Us</a>
                
            </div>
        </div>
        <div class="maindiv">
        	<div class="leftpanel">