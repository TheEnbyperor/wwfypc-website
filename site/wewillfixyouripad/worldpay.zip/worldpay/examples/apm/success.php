<?php
include('../header.php');
echo 'APM Order ' . $_GET['orderCode'] . ' has been authorized <br/>';
