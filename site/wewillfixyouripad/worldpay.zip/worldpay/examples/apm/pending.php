<?php
include('../header.php');
echo 'APM Order ' . $_GET['orderCode'] . ' has been marked as pending<br/>';
