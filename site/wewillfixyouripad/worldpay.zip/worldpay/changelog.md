### 2.1.0 2016-08-01
* Remove multiple IP Addresses sent with Utils
* Add customerOrderCode

### 2.0.0 2016-04-20
* Code Refactor
* TelephoneNumber added to AddressObject
* Shopper Data refactored
* Reference Classing
* Composer Support
* Packagist Linking

### 1.8 2016-02-03
* Shopper Language Code Fix
* Reusable Flag for Direct Orders
* Added CustomerIdentifiers on Cardonfile
* Code Refactor
* Added Missing Fields on Cardonfile Form
* Support Direct PAN orders
* Order Code Suffixes and Prefixes
* Always send name as "3D" in order request for 3DS live orders
* Empty settlement currency fix

### 1.7 2015-10-16
* Support Zero Auth

### 1.6 2015-05-27
* Check is_numeric instead of is_int for Captures

### 1.5 2015-05-19
* Modify PHP library timeout period and message

### 1.4 2015-03-04
* PHP 5.2 Error Exeption Handling
* Authorisations

### 1.3 2015-02-06
* Initial updated public PHP library

