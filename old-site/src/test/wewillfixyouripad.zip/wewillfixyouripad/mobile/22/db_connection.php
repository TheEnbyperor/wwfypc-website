<?php
$host = "localhost";
$user = "wewillf2_neilp";
$pass = "password1";
$db = "wewillf2_sabritech";

$conn = mysql_connect($host, $user, $pass);
if(!$conn){
	echo "could not connect";
}

$db_select = mysql_select_db($db);

if(!$db){
	echo "no database";
}

?>