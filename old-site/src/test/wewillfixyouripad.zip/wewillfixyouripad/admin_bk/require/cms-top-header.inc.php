<?php
include_once("../admin/require/webconfig.inc.php");
?>
<table width="998" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="109" background="images/imsg-top_bg.jpg"><table width="950" border="0" align="left" cellpadding="0" cellspacing="0">
        <tr>
          <td width="152" align="left"><img src="images/img-logo.gif"></td>
          <td width="798" align="right" class="bluetitle"><?=WEBSITE_NAME?> Administrator</td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td height="56" background="images/img-tab_bg.jpg" style="padding-left:35px;"><table width="940" height="27" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="296" valign="bottom"><img src="images/img-content_title.jpg" width="252" height="23"></td>
          <td width="644"><table width="460" border="0" align="right" cellpadding="0" cellspacing="0">
              <tr>
                <td width="116" align="right" style="padding-right:10px;"><img src="images/icon-home.jpg" width="26" height="25"></td>
                <td width="67" class="tblink"><a href="control-panel.php" title="Home">Home</a></td>
                <td width="37"><img src="images/icon-change_pass.jpg" width="25" height="25"></td>
                <td width="130" class="tblink"><a href="change-password.php" title="Change Password">Change Password</a> </td>
                <td width="34"><img src="images/icon-logout.jpg" width="22" height="25"></td>
                <td width="76" class="tblink"><a href="cms-logout.php" title="Logout">Logout</a></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
</table>