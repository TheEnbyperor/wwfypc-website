<table width="301" border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td width="301"  align="right"><span class="bodytext">&copy; All Rights Reserved to</span> <a href="http://www.sabritech.com" target="_blank" class="footerlink">SabriTech</a>&nbsp;&nbsp;&nbsp;</td>
      </tr>
    </table>
