<table class="table_footer">
							  <tr>
								<td class="c1">© Copyright - Ealing Hospital 2009 All Rights Reserved<br />
							    Powered by <a href="http://www.sabritech.com" target="_blank">SabriTech</a></td>
								<td class="c2"></td>
								<td class="c3">
									<table class="table_menu">
									  <tr>
										<td class="c1"><a class="link" href="index.php">Main Page</a></td>
										<td class="c2"></td>
										<td class="c1"><a class="link" href="aboutus.php">About us</a></td>
										<td class="c2"></td>
										<td class="c1"><a class="link" href="services.php">Services</a></td>
										<td class="c2"></td>
										<td class="c1"><a class="link" href="support.php">Support</a></td>
										<td class="c2"></td>
										<td class="c1"><a class="link" href="contactus.php">Contacts</a></td>
									  </tr>
									</table>
								</td>
							  </tr>
							</table>