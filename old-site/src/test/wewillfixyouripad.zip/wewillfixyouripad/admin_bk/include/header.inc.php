<div><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
					   codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,24"
					   width="800" height="415">
						<param name="movie" value="flash/header_vf8.swf?button=1" /> 
						<param name="quality" value="high" />
						<param name="menu" value="false" />
						<!--[if !IE]> <-->
						<object data="flash/header_vf8.swf?button=1"
								width="800" height="415" type="application/x-shockwave-flash">
						 <param name="quality" value="high" />
						 <param name="menu" value="false" />
						 <param name="pluginurl" value="http://www.macromedia.com/go/getflashplayer" />
						 FAIL (the browser should render some flash content, not this).
						</object>
						<!--> <![endif]-->
					   </object></div>		